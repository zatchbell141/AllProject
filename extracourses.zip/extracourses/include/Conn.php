<?php
$mysql_host='localhost';
$mysql_user='root';
$mysql_pswd='';
$mysql_database='extracourses';
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_pswd,$mysql_database);
//echo "test";
?>
